import time
import random

def play_beetles_upgrade():
    #Dictionary declaring body_part variables. Setting them to zero and false
    body_parts = {
        "body": False,
        "head": False,
        "antennae": 0,
        "eyes": 0,
        "mouth": False,
        "legs": 0
    }

    #Counts to track various aspects of the game
    counter = {
        "miss": 0, #Did not successfully add a body part
        "roll_attempts": 0, #Number of total dice throws
        "successful_additions": 0 #successfully collected a body part
    }

    print("Welcome to the Beetle game(Upgrade)!\nThe objective is to collect all the body parts of a Beetle.\nEach roll of the dice will give you a body part.\nYou need a body before any other body parts can be added.\nYou need a head before any antennae, eyes, or mouth can be added.\nA complete Beetle consists of one body, one head, two antennae, two eyes, one mouth, and six legs.\nAt the end of the game, your statistics will be displayed\nLet's begin.\n")

    while True: #infinite loop
        if (val == True for val in body_parts.values()) and body_parts['antennae'] == 2 and body_parts['eyes'] == 2 and body_parts['legs'] == 6:
                print("Congratulations! You have collected all the body parts of a Beetle.")
                print("Your game statistics:", counter)
                break #Checks if body_parts are complete according to condition (Beetle body = one body, one head, two antennae, two eyes, one mouth, and six legs.) If True loop is broken

        choice = input("Do you want to roll the dice? (yes/no): ")
        if choice.lower() == "yes":
            print("Rolling the dice...")
            time.sleep(1) #1 second delay to improve plyer experience. Delay simulates a rolling dice
            roll = random.randint(1, 6) #Randomly generate faces of a die
            print("You got", roll)
            counter["roll_attempts"] += 1 # +1 to roll_attempts in 'counter'

            #Conditions
            if roll == 1 and not body_parts["body"]: # if roll equal 1 and body in body_parts is false...
                body_parts["body"] = True #changes value of body in dictionary 'body_parts' to true
                print("You got a body.")
                counter["successful_additions"] += 1
            elif roll == 2 and not body_parts["head"]:
                body_parts["head"] = True
                print("You got a head.")
                counter["successful_additions"] += 1 # +1 to successful_additions in 'counter'
            elif roll == 3 and body_parts["head"] and body_parts["antennae"] < 2: #if roll equal 3, head is True and antennae in body_parts less than 2...
                body_parts["antennae"] += 1 #adds +1 to antennae in body_parts
                print("You got an antenna.")
                counter["successful_additions"] += 1
            elif roll == 4 and body_parts["head"] and body_parts["eyes"] < 2:
                body_parts["eyes"] += 1
                print("You got an eye.")
                counter["successful_additions"] += 1
            elif roll == 5 and body_parts["head"] and not body_parts["mouth"]:
                body_parts["mouth"] = True
                print("You got a mouth.")
                counter["successful_additions"] += 1
            elif roll == 6 and body_parts["body"] and body_parts["legs"] < 6:
                body_parts["legs"] += 1
                print("You got a leg.")
                counter["successful_additions"] += 1
            else:
                print("You can't add this body part now.") #prints this if conditions for adding a body_part is not met
                counter["miss"] += 1 # +1 to miss in 'counter'
            print("Your beetle so far:", body_parts) #Prints current keys & values of the dictionary body_parts
        else: #Exits game if input from 'choice' variable != 'yes'
            print("Exiting the game...")
            break

if __name__ == "__main__":
    play_beetles_upgrade()
